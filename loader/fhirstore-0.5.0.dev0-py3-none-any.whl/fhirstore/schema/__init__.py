from .parser import SchemaParser  # noqa
